# Extension Icons

This folder should contain the extension icons in the following sizes:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels) 
- icon128.png (128x128 pixels)

## Creating Icons

You can create simple icons using these emoji as a base:
- 🧠 (brain emoji for AI/ML theme)
- 😊 (smiling emoji for emotion detection)
- 💭 (thought bubble for sentiment analysis)

## Recommended Tools

1. **Online Icon Generators:**
   - Favicon.io
   - Canva
   - Figma

2. **Design Guidelines:**
   - Use a simple, recognizable design
   - Ensure good contrast for visibility
   - Keep the design scalable
   - Use consistent colors across all sizes

## Colors to Use

Based on the extension theme:
- Primary: #6366f1 (indigo)
- Secondary: #8b5cf6 (purple) 
- Accent: #10b981 (emerald)
- Background: White or transparent

## Quick Icon Creation

If you need placeholder icons immediately, you can:
1. Use emoji-to-PNG converters online
2. Create simple text-based icons with the letters "ET" (Emoji Tone)
3. Use geometric shapes with the theme colors

The extension will work without custom icons (Chrome will generate defaults), but custom icons improve the user experience.