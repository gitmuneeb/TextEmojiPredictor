// Popup functionality for the emoji tone detector extension
class PopupController {
    constructor() {
        this.isAnalyzing = false;
        this.analysisTimeout = null;
        this.settings = {
            enabled: true,
            showConfidence: true,
            delay: 800
        };
        
        this.init();
    }
    
    async init() {
        await this.loadSettings();
        this.setupEventListeners();
        this.updateUI();
    }
    
    async loadSettings() {
        const stored = await chrome.storage.sync.get(['extensionSettings']);
        if (stored.extensionSettings) {
            this.settings = { ...this.settings, ...stored.extensionSettings };
        }
    }
    
    async saveSettings() {
        await chrome.storage.sync.set({ extensionSettings: this.settings });
    }
    
    setupEventListeners() {
        // Test text analysis
        const testText = document.getElementById('testText');
        testText.addEventListener('input', (e) => {
            this.debouncedAnalyze(e.target.value);
        });
        
        // Settings
        const enableExtension = document.getElementById('enableExtension');
        enableExtension.checked = this.settings.enabled;
        enableExtension.addEventListener('change', (e) => {
            this.settings.enabled = e.target.checked;
            this.saveSettings();
            this.updateStatus();
        });
        
        const showConfidence = document.getElementById('showConfidence');
        showConfidence.checked = this.settings.showConfidence;
        showConfidence.addEventListener('change', (e) => {
            this.settings.showConfidence = e.target.checked;
            this.saveSettings();
        });
        
        const delaySlider = document.getElementById('delaySlider');
        const delayValue = document.getElementById('delayValue');
        delaySlider.value = this.settings.delay;
        delayValue.textContent = this.settings.delay;
        
        delaySlider.addEventListener('input', (e) => {
            const value = e.target.value;
            delayValue.textContent = value;
            this.settings.delay = parseInt(value);
            this.saveSettings();
        });
        
        // Action buttons
        document.getElementById('trainBtn').addEventListener('click', () => {
            chrome.tabs.create({ url: 'https://your-app-url.replit.app/training' });
        });
        
        document.getElementById('settingsBtn').addEventListener('click', () => {
            // Could open a more detailed settings page
            console.log('Settings clicked');
        });
    }
    
    updateUI() {
        this.updateStatus();
    }
    
    updateStatus() {
        const statusText = document.getElementById('statusText');
        const statusIndicator = document.getElementById('statusIndicator');
        
        if (this.settings.enabled) {
            statusText.textContent = 'Active on all websites';
            statusIndicator.style.background = '#22c55e';
        } else {
            statusText.textContent = 'Disabled';
            statusIndicator.style.background = '#ef4444';
        }
    }
    
    debouncedAnalyze(text) {
        if (this.analysisTimeout) {
            clearTimeout(this.analysisTimeout);
        }
        
        const resultDiv = document.getElementById('result');
        
        if (!text.trim() || text.length < 3) {
            resultDiv.style.display = 'none';
            return;
        }
        
        this.analysisTimeout = setTimeout(() => {
            this.analyzeText(text);
        }, 500); // Faster response in popup
    }
    
    async analyzeText(text) {
        if (this.isAnalyzing) return;
        
        this.isAnalyzing = true;
        const resultDiv = document.getElementById('result');
        
        try {
            // Use the built-in analysis engine (embedded in extension)
            const result = this.localAnalyze(text);
            this.displayResult(result);
            resultDiv.style.display = 'block';
        } catch (error) {
            console.error('Analysis error:', error);
            resultDiv.style.display = 'none';
        }
        
        this.isAnalyzing = false;
    }
    
    // Embedded analysis engine (simplified version)
    localAnalyze(text) {
        const lowerText = text.toLowerCase();
        const words = lowerText.split(/[\s.,!?;:]+/).filter(word => word.length > 0);
        
        // Simplified keyword mapping
        const keywords = {
            positive: ['good', 'great', 'awesome', 'amazing', 'excellent', 'wonderful', 'fantastic', 'love', 'happy', 'joy'],
            negative: ['bad', 'terrible', 'awful', 'hate', 'sad', 'angry', 'disappointed', 'frustrated', 'annoyed'],
            excited: ['excited', 'thrilled', 'pumped', 'energetic', 'enthusiastic', 'can\'t wait', 'so excited'],
            love: ['love', 'adore', 'cherish', 'romantic', 'heart', 'kiss', 'valentine', 'darling', 'sweetheart'],
            funny: ['funny', 'hilarious', 'lol', 'haha', 'comedy', 'joke', 'humor', 'laugh', 'amusing'],
            surprise: ['wow', 'omg', 'incredible', 'unbelievable', 'shocking', 'surprised', 'amazing', 'whoa']
        };
        
        const emojiMap = {
            positive: ['😊', '😀', '🙂', '😁', '👍', '✨', '🌟', '😎'],
            negative: ['😞', '😢', '😠', '👎', '😤', '😡', '😔', '🙁'],
            excited: ['🎉', '🤩', '😍', '🚀', '⚡', '🔥', '🎊', '💫'],
            love: ['❤️', '💕', '😘', '💖', '💝', '😍', '🥰', '💗'],
            funny: ['😂', '🤣', '😆', '😄', '😹', '🤭', '😋', '🤪'],
            surprise: ['😲', '😳', '🤯', '😱', '🤨', '😮', '👀', '🙄'],
            neutral: ['😐', '🤔', '😌', '🙂', '😊']
        };
        
        const toneScores = {};
        const detectedKeywords = [];
        
        // Score each tone
        for (const [tone, toneKeywords] of Object.entries(keywords)) {
            toneScores[tone] = 0;
            
            words.forEach(word => {
                toneKeywords.forEach(keyword => {
                    if (word.includes(keyword)) {
                        toneScores[tone] += 1;
                        detectedKeywords.push(word);
                    }
                });
            });
        }
        
        // Handle negations
        const hasNegation = /\b(not|don't|doesn't|can't|won't|isn't|aren't)\b/.test(lowerText);
        if (hasNegation && toneScores.positive > 0) {
            toneScores.negative += toneScores.positive;
            toneScores.positive = 0;
        }
        
        // Find dominant tone
        let maxScore = 0;
        let dominantTone = 'neutral';
        
        for (const [tone, score] of Object.entries(toneScores)) {
            if (score > maxScore) {
                maxScore = score;
                dominantTone = tone;
            }
        }
        
        // Calculate confidence
        const totalWords = words.length;
        const keywordDensity = detectedKeywords.length / Math.max(totalWords, 1);
        const confidence = Math.min(Math.round(keywordDensity * 100 + 20), 100);
        
        return {
            tone: dominantTone,
            confidence,
            keywords: detectedKeywords,
            emojis: emojiMap[dominantTone] || emojiMap.neutral
        };
    }
    
    displayResult(result) {
        document.getElementById('emojiDisplay').textContent = result.emojis[0];
        document.getElementById('toneLabel').textContent = result.tone;
        
        const confidenceEl = document.getElementById('confidence');
        if (this.settings.showConfidence) {
            confidenceEl.textContent = `${result.confidence}%`;
            confidenceEl.style.display = 'inline';
        } else {
            confidenceEl.style.display = 'none';
        }
        
        const keywordsEl = document.getElementById('keywords');
        if (result.keywords.length > 0) {
            keywordsEl.textContent = `Keywords: ${result.keywords.join(', ')}`;
        } else {
            keywordsEl.textContent = '';
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PopupController();
});