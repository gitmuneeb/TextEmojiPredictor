// Background service worker for emoji tone detector extension
class BackgroundService {
    constructor() {
        this.init();
    }
    
    init() {
        // Handle extension installation
        chrome.runtime.onInstalled.addListener((details) => {
            if (details.reason === 'install') {
                this.onInstall();
            } else if (details.reason === 'update') {
                this.onUpdate(details.previousVersion);
            }
        });
        
        // Handle browser action clicks
        chrome.action.onClicked.addListener((tab) => {
            // This is handled by the popup, but we can add fallback behavior here
            console.log('Extension clicked on tab:', tab.id);
        });
        
        // Listen for messages from content scripts
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.handleMessage(request, sender, sendResponse);
            return true; // Keep message channel open for async responses
        });
        
        // Set default settings on installation
        this.setDefaultSettings();
    }
    
    async onInstall() {
        console.log('Emoji Tone Detector extension installed');
        
        // Set default settings
        await this.setDefaultSettings();
        
        // Show welcome notification
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'Emoji Tone Detector',
            message: 'Extension installed! Start typing in any text field to see emoji suggestions.'
        });
    }
    
    async onUpdate(previousVersion) {
        console.log(`Extension updated from ${previousVersion} to ${chrome.runtime.getManifest().version}`);
        
        // Handle any migration if needed
        await this.migrateSettings(previousVersion);
    }
    
    async setDefaultSettings() {
        const defaultSettings = {
            enabled: true,
            showConfidence: true,
            delay: 800,
            autoInsert: false,
            keyboardShortcut: 'Ctrl+E'
        };
        
        try {
            const existing = await chrome.storage.sync.get(['extensionSettings']);
            if (!existing.extensionSettings) {
                await chrome.storage.sync.set({ extensionSettings: defaultSettings });
                console.log('Default settings applied');
            }
        } catch (error) {
            console.error('Error setting default settings:', error);
        }
    }
    
    async migrateSettings(previousVersion) {
        try {
            const stored = await chrome.storage.sync.get(['extensionSettings']);
            let settings = stored.extensionSettings || {};
            
            // Add any new settings that weren't in previous versions
            const newDefaults = {
                autoInsert: false,
                keyboardShortcut: 'Ctrl+E'
            };
            
            let updated = false;
            for (const [key, value] of Object.entries(newDefaults)) {
                if (!(key in settings)) {
                    settings[key] = value;
                    updated = true;
                }
            }
            
            if (updated) {
                await chrome.storage.sync.set({ extensionSettings: settings });
                console.log('Settings migrated for version', chrome.runtime.getManifest().version);
            }
        } catch (error) {
            console.error('Error migrating settings:', error);
        }
    }
    
    handleMessage(request, sender, sendResponse) {
        switch (request.action) {
            case 'analyzeText':
                this.analyzeText(request.text).then(sendResponse);
                break;
                
            case 'getSettings':
                this.getSettings().then(sendResponse);
                break;
                
            case 'saveSettings':
                this.saveSettings(request.settings).then(sendResponse);
                break;
                
            case 'openTrainingPage':
                this.openTrainingPage();
                sendResponse({ success: true });
                break;
                
            case 'getStats':
                this.getUsageStats().then(sendResponse);
                break;
                
            default:
                console.warn('Unknown message action:', request.action);
                sendResponse({ error: 'Unknown action' });
        }
    }
    
    async analyzeText(text) {
        // This could be enhanced to use the actual server API when available
        // For now, return a simple local analysis
        return {
            tone: 'positive',
            confidence: 75,
            emojis: ['😊', '👍', '✨'],
            keywords: ['good', 'great']
        };
    }
    
    async getSettings() {
        try {
            const result = await chrome.storage.sync.get(['extensionSettings']);
            return result.extensionSettings || {};
        } catch (error) {
            console.error('Error getting settings:', error);
            return {};
        }
    }
    
    async saveSettings(settings) {
        try {
            await chrome.storage.sync.set({ extensionSettings: settings });
            return { success: true };
        } catch (error) {
            console.error('Error saving settings:', error);
            return { success: false, error: error.message };
        }
    }
    
    openTrainingPage() {
        // Open the training page of the web app
        const trainingUrl = 'https://your-app-url.replit.app/training';
        chrome.tabs.create({ url: trainingUrl });
    }
    
    async getUsageStats() {
        try {
            const stats = await chrome.storage.local.get(['usageStats']);
            return stats.usageStats || {
                totalAnalyses: 0,
                emojisInserted: 0,
                mostUsedTone: 'neutral',
                dailyUsage: {}
            };
        } catch (error) {
            console.error('Error getting usage stats:', error);
            return {};
        }
    }
    
    async updateUsageStats(analysisResult) {
        try {
            const stored = await chrome.storage.local.get(['usageStats']);
            const stats = stored.usageStats || {
                totalAnalyses: 0,
                emojisInserted: 0,
                mostUsedTone: 'neutral',
                dailyUsage: {},
                toneDistribution: {}
            };
            
            stats.totalAnalyses++;
            
            // Update tone distribution
            const tone = analysisResult.tone;
            stats.toneDistribution[tone] = (stats.toneDistribution[tone] || 0) + 1;
            
            // Update most used tone
            const maxTone = Object.keys(stats.toneDistribution).reduce((a, b) => 
                stats.toneDistribution[a] > stats.toneDistribution[b] ? a : b
            );
            stats.mostUsedTone = maxTone;
            
            // Update daily usage
            const today = new Date().toISOString().split('T')[0];
            stats.dailyUsage[today] = (stats.dailyUsage[today] || 0) + 1;
            
            await chrome.storage.local.set({ usageStats: stats });
        } catch (error) {
            console.error('Error updating usage stats:', error);
        }
    }
}

// Initialize background service
new BackgroundService();