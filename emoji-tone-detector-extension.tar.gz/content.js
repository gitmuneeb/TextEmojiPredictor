// Content script for emoji tone detector browser extension
class EmojiToneDetectorContent {
    constructor() {
        this.isEnabled = true;
        this.showConfidence = true;
        this.delay = 800;
        this.analysisTimeout = null;
        this.currentTooltip = null;
        this.lastAnalyzedElement = null;
        
        this.init();
    }
    
    async init() {
        await this.loadSettings();
        if (this.isEnabled) {
            this.setupEventListeners();
            this.injectStyles();
        }
        
        // Listen for settings changes
        chrome.storage.onChanged.addListener((changes, namespace) => {
            if (namespace === 'sync' && changes.extensionSettings) {
                this.loadSettings();
            }
        });
    }
    
    async loadSettings() {
        const stored = await chrome.storage.sync.get(['extensionSettings']);
        if (stored.extensionSettings) {
            this.isEnabled = stored.extensionSettings.enabled !== false;
            this.showConfidence = stored.extensionSettings.showConfidence !== false;
            this.delay = stored.extensionSettings.delay || 800;
        }
    }
    
    setupEventListeners() {
        // Listen for text inputs on the page
        document.addEventListener('input', (e) => {
            if (this.isTextInput(e.target) && this.isEnabled) {
                this.handleTextInput(e.target);
            }
        }, true);
        
        // Hide tooltip when clicking elsewhere
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.emoji-tone-tooltip')) {
                this.hideTooltip();
            }
        });
        
        // Hide tooltip on scroll
        window.addEventListener('scroll', () => {
            this.hideTooltip();
        });
        
        // Handle dynamic content
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) { // Element node
                        this.setupTextInputs(node);
                    }
                });
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        
        // Setup existing inputs
        this.setupTextInputs(document);
    }
    
    setupTextInputs(container) {
        const inputs = container.querySelectorAll('textarea, input[type="text"], [contenteditable="true"]');
        inputs.forEach(input => {
            if (!input.hasAttribute('data-emoji-tone-setup')) {
                input.setAttribute('data-emoji-tone-setup', 'true');
                // Additional setup if needed
            }
        });
    }
    
    isTextInput(element) {
        const tagName = element.tagName.toLowerCase();
        return (
            tagName === 'textarea' ||
            (tagName === 'input' && element.type === 'text') ||
            element.contentEditable === 'true' ||
            element.isContentEditable
        );
    }
    
    handleTextInput(element) {
        if (this.analysisTimeout) {
            clearTimeout(this.analysisTimeout);
        }
        
        this.lastAnalyzedElement = element;
        
        this.analysisTimeout = setTimeout(() => {
            const text = this.getElementText(element);
            if (text.trim().length >= 3) {
                this.analyzeAndShowTooltip(element, text);
            } else {
                this.hideTooltip();
            }
        }, this.delay);
    }
    
    getElementText(element) {
        if (element.tagName.toLowerCase() === 'textarea' || element.tagName.toLowerCase() === 'input') {
            return element.value;
        } else if (element.contentEditable === 'true' || element.isContentEditable) {
            return element.textContent || element.innerText;
        }
        return '';
    }
    
    analyzeAndShowTooltip(element, text) {
        const analysis = this.analyzeText(text);
        this.showTooltip(element, analysis);
    }
    
    analyzeText(text) {
        const lowerText = text.toLowerCase();
        const words = lowerText.split(/[\s.,!?;:]+/).filter(word => word.length > 0);
        
        // Enhanced keyword mapping
        const keywords = {
            positive: {
                strong: ['fantastic', 'amazing', 'wonderful', 'excellent', 'brilliant', 'outstanding', 'perfect', 'incredible'],
                medium: ['good', 'great', 'nice', 'awesome', 'cool', 'fine', 'okay', 'pleasant'],
                light: ['happy', 'glad', 'pleased', 'satisfied', 'content', 'cheerful']
            },
            negative: {
                strong: ['terrible', 'awful', 'horrible', 'disgusting', 'pathetic', 'despise', 'furious', 'devastated'],
                medium: ['bad', 'wrong', 'poor', 'disappointing', 'annoying', 'frustrating', 'unpleasant'],
                light: ['sad', 'upset', 'concerned', 'worried', 'bothered', 'troubled']
            },
            excited: {
                strong: ['thrilled', 'ecstatic', 'exhilarated', 'euphoric', 'overjoyed'],
                medium: ['excited', 'enthusiastic', 'eager', 'pumped', 'energetic'],
                light: ['interested', 'curious', 'looking forward', 'anticipating']
            },
            love: {
                strong: ['adore', 'worship', 'treasure', 'cherish', 'devoted'],
                medium: ['love', 'care', 'affection', 'romantic', 'intimate'],
                light: ['like', 'fond', 'appreciate', 'enjoy', 'prefer']
            },
            funny: {
                strong: ['hilarious', 'hysterical', 'ridiculous', 'absurd'],
                medium: ['funny', 'amusing', 'entertaining', 'comical', 'witty'],
                light: ['silly', 'playful', 'humorous', 'lighthearted']
            },
            angry: {
                strong: ['furious', 'enraged', 'livid', 'irate', 'outraged'],
                medium: ['angry', 'mad', 'annoyed', 'irritated', 'frustrated'],
                light: ['bothered', 'displeased', 'agitated', 'irked']
            }
        };
        
        const emojiMap = {
            positive: ['😊', '😀', '🙂', '😁', '👍', '✨', '🌟', '😎'],
            negative: ['😞', '😢', '😠', '👎', '😤', '😡', '😔', '🙁'],
            excited: ['🎉', '🤩', '😍', '🚀', '⚡', '🔥', '🎊', '💫'],
            love: ['❤️', '💕', '😘', '💖', '💝', '😍', '🥰', '💗'],
            funny: ['😂', '🤣', '😆', '😄', '😹', '🤭', '😋', '🤪'],
            angry: ['😠', '😡', '🤬', '😤', '👿', '💢', '🔥', '⚡'],
            surprise: ['😲', '😳', '🤯', '😱', '🤨', '😮', '👀', '🙄'],
            neutral: ['😐', '🤔', '😌', '🙂', '😊']
        };
        
        const toneScores = {};
        const detectedKeywords = [];
        
        // Initialize scores
        Object.keys(keywords).forEach(tone => {
            toneScores[tone] = 0;
        });
        
        // Score words
        words.forEach(word => {
            Object.entries(keywords).forEach(([tone, intensities]) => {
                Object.entries(intensities).forEach(([intensity, keywordList]) => {
                    keywordList.forEach(keyword => {
                        if (word.includes(keyword.toLowerCase())) {
                            const multiplier = intensity === 'strong' ? 3 : intensity === 'medium' ? 2 : 1;
                            toneScores[tone] += multiplier;
                            detectedKeywords.push(word);
                        }
                    });
                });
            });
        });
        
        // Handle common phrases
        const phrases = {
            excited: [/can't wait/i, /so excited/i, /looking forward/i],
            love: [/love you/i, /miss you/i, /thinking of you/i],
            negative: [/not good/i, /don't like/i, /can't stand/i],
            positive: [/feel good/i, /going well/i, /works great/i]
        };
        
        Object.entries(phrases).forEach(([tone, patternList]) => {
            patternList.forEach(pattern => {
                if (pattern.test(text)) {
                    toneScores[tone] += 2;
                    detectedKeywords.push('phrase detected');
                }
            });
        });
        
        // Handle negations
        const hasNegation = /\b(not|don't|doesn't|can't|won't|isn't|aren't)\b/.test(lowerText);
        if (hasNegation && toneScores.positive > 0) {
            toneScores.negative += toneScores.positive;
            toneScores.positive = 0;
        }
        
        // Find dominant tone
        let maxScore = 0;
        let dominantTone = 'neutral';
        
        Object.entries(toneScores).forEach(([tone, score]) => {
            if (score > maxScore) {
                maxScore = score;
                dominantTone = tone;
            }
        });
        
        // Calculate confidence
        const totalWords = words.length;
        const keywordDensity = detectedKeywords.length / Math.max(totalWords, 1);
        const baseConfidence = Math.min(keywordDensity * 80, 80);
        const lengthBonus = Math.min(totalWords * 2, 20);
        const confidence = Math.round(baseConfidence + lengthBonus);
        
        return {
            tone: dominantTone,
            confidence: Math.min(confidence, 100),
            keywords: [...new Set(detectedKeywords)], // Remove duplicates
            emojis: emojiMap[dominantTone] || emojiMap.neutral
        };
    }
    
    showTooltip(element, analysis) {
        this.hideTooltip();
        
        const tooltip = document.createElement('div');
        tooltip.className = 'emoji-tone-tooltip';
        tooltip.innerHTML = `
            <div class="emoji-display">${analysis.emojis[0]}</div>
            <div class="tone-info">
                <span class="tone-name">${analysis.tone}</span>
                ${this.showConfidence ? `<span class="confidence">${analysis.confidence}%</span>` : ''}
            </div>
            <div class="emoji-options">
                ${analysis.emojis.slice(0, 4).map(emoji => 
                    `<span class="emoji-option" data-emoji="${emoji}">${emoji}</span>`
                ).join('')}
            </div>
        `;
        
        // Position tooltip
        const rect = element.getBoundingClientRect();
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
        
        tooltip.style.position = 'absolute';
        tooltip.style.top = (rect.bottom + scrollTop + 5) + 'px';
        tooltip.style.left = (rect.left + scrollLeft) + 'px';
        tooltip.style.zIndex = '10000';
        
        // Add click handlers for emoji options
        tooltip.querySelectorAll('.emoji-option').forEach(option => {
            option.addEventListener('click', (e) => {
                const emoji = e.target.getAttribute('data-emoji');
                this.insertEmoji(element, emoji);
                this.hideTooltip();
            });
        });
        
        document.body.appendChild(tooltip);
        this.currentTooltip = tooltip;
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            this.hideTooltip();
        }, 5000);
    }
    
    insertEmoji(element, emoji) {
        if (element.tagName.toLowerCase() === 'textarea' || element.tagName.toLowerCase() === 'input') {
            const start = element.selectionStart;
            const end = element.selectionEnd;
            const text = element.value;
            element.value = text.slice(0, start) + emoji + ' ' + text.slice(end);
            element.selectionStart = element.selectionEnd = start + emoji.length + 1;
        } else if (element.contentEditable === 'true' || element.isContentEditable) {
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                range.deleteContents();
                range.insertNode(document.createTextNode(emoji + ' '));
                range.collapse(false);
            }
        }
        
        // Trigger input event to notify other scripts
        element.dispatchEvent(new Event('input', { bubbles: true }));
    }
    
    hideTooltip() {
        if (this.currentTooltip) {
            this.currentTooltip.remove();
            this.currentTooltip = null;
        }
    }
    
    injectStyles() {
        if (document.getElementById('emoji-tone-detector-styles')) return;
        
        const styles = document.createElement('style');
        styles.id = 'emoji-tone-detector-styles';
        styles.textContent = `
            .emoji-tone-tooltip {
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                padding: 12px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 14px;
                max-width: 200px;
                backdrop-filter: blur(10px);
                animation: tooltipFadeIn 0.2s ease-out;
            }
            
            @keyframes tooltipFadeIn {
                from { opacity: 0; transform: translateY(-5px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .emoji-tone-tooltip .emoji-display {
                font-size: 24px;
                text-align: center;
                margin-bottom: 8px;
            }
            
            .emoji-tone-tooltip .tone-info {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 8px;
            }
            
            .emoji-tone-tooltip .tone-name {
                font-weight: 600;
                color: #374151;
                text-transform: capitalize;
            }
            
            .emoji-tone-tooltip .confidence {
                font-size: 12px;
                color: #6b7280;
                background: #f3f4f6;
                padding: 2px 6px;
                border-radius: 10px;
            }
            
            .emoji-tone-tooltip .emoji-options {
                display: flex;
                gap: 4px;
                justify-content: center;
            }
            
            .emoji-tone-tooltip .emoji-option {
                font-size: 18px;
                cursor: pointer;
                padding: 4px;
                border-radius: 4px;
                transition: background-color 0.2s;
            }
            
            .emoji-tone-tooltip .emoji-option:hover {
                background-color: #f3f4f6;
            }
        `;
        
        document.head.appendChild(styles);
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new EmojiToneDetectorContent();
    });
} else {
    new EmojiToneDetectorContent();
}