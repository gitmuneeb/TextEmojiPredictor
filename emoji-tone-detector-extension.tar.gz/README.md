# Emoji Tone Detector Browser Extension

A browser extension that analyzes emotional tone in text as you type and suggests relevant emojis across any website.

## Features

🧠 **Real-time Analysis** - Detects emotional tone as you type in any text field
😊 **Smart Emoji Suggestions** - Shows relevant emojis based on detected emotions
🎯 **Click to Insert** - One-click emoji insertion into text fields
⚙️ **Customizable Settings** - Adjust delay, confidence display, and more
📊 **Usage Statistics** - Track your emoji usage patterns
🔄 **Cross-Website Support** - Works on all websites including social media, email, and messaging

## Installation

### Method 1: Load Unpacked Extension (Development)

1. **Download the Extension Files**
   - Copy all files from the `browser-extension` folder

2. **Open Chrome Extensions Page**
   - Navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)

3. **Load the Extension**
   - Click "Load unpacked"
   - Select the `browser-extension` folder
   - The extension should appear in your toolbar

### Method 2: Chrome Web Store (Future)
The extension will be available on the Chrome Web Store after review.

## How to Use

1. **Start Typing** - Open any website and start typing in a text field
2. **See Analysis** - After a brief delay, a tooltip will appear showing:
   - Primary emoji suggestion
   - Detected emotional tone
   - Confidence level (optional)
   - Additional emoji options
3. **Insert Emojis** - Click any emoji in the tooltip to insert it
4. **Customize** - Click the extension icon to adjust settings

### Supported Text Fields
- Text inputs (`<input type="text">`)
- Textareas (`<textarea>`)
- Contenteditable elements
- Most messaging and social media platforms

## Settings

Access settings by clicking the extension icon in the toolbar:

- **Enable/Disable** - Turn the extension on/off globally
- **Show Confidence** - Display confidence percentages
- **Analysis Delay** - Adjust how quickly analysis triggers (300-2000ms)
- **Training Access** - Link to the web app's training interface

## Technical Details

### Architecture
- **Manifest V3** - Uses latest Chrome extension standards
- **Content Script** - Analyzes text and shows tooltips on web pages
- **Background Service Worker** - Handles settings and cross-tab communication
- **Popup Interface** - Provides settings and testing functionality

### Analysis Engine
The extension includes a built-in sentiment analysis engine with:
- **Keyword Matching** - Enhanced dictionary with intensity levels
- **Context Awareness** - Understands phrases and sentence structure
- **Negation Handling** - Properly processes "not good" vs "good"
- **Punctuation Analysis** - Detects emphasis (!!!, CAPS, etc.)

### Privacy
- **Local Processing** - All analysis happens locally in your browser
- **No Data Collection** - No personal data is sent to external servers
- **Storage** - Only stores your preferences locally

## Development

### File Structure
```
browser-extension/
├── manifest.json          # Extension configuration
├── popup.html             # Extension popup interface
├── popup.css              # Popup styling
├── popup.js               # Popup functionality
├── content.js             # Main content script
├── content.css            # Content script styles
├── background.js          # Service worker
├── icons/                 # Extension icons
└── README.md              # This file
```

### Key Components

**Content Script (`content.js`)**
- Monitors text input across all web pages
- Performs real-time sentiment analysis
- Shows/hides emoji suggestion tooltips
- Handles emoji insertion

**Popup (`popup.html/js/css`)**
- Settings interface
- Live analysis testing
- Links to training interface
- Extension status display

**Background Service Worker (`background.js`)**
- Manages extension lifecycle
- Handles settings synchronization
- Provides cross-tab communication
- Tracks usage statistics

### Analysis Algorithm

The extension uses a sophisticated multi-layer analysis:

1. **Text Preprocessing** - Normalizes input and extracts words
2. **Keyword Scoring** - Matches against categorized emotion dictionaries
3. **Phrase Detection** - Recognizes common emotional expressions
4. **Context Analysis** - Handles negations and qualifiers
5. **Confidence Calculation** - Assigns reliability scores
6. **Emoji Selection** - Maps emotions to relevant emoji sets

### Customization

You can customize the analysis by modifying the keyword dictionaries in `content.js`:

```javascript
const keywords = {
    positive: {
        strong: ['fantastic', 'amazing', 'wonderful'],
        medium: ['good', 'great', 'nice'],
        light: ['happy', 'glad', 'pleased']
    }
    // ... add more emotions and keywords
};
```

## Integration with Web App

The extension integrates with the main Emoji Tone Detector web application:
- **Training Interface** - Links to `/training` page for ML improvements
- **Shared Algorithm** - Uses similar analysis logic for consistency
- **Future Sync** - Planned feature to sync learning data

## Browser Compatibility

- **Chrome** - Fully supported (Manifest V3)
- **Edge** - Compatible (uses Chromium)
- **Firefox** - Requires minor modifications for Manifest V2
- **Safari** - Requires adaptation for Safari Web Extensions

## Performance

- **Lightweight** - Minimal impact on page load times
- **Efficient** - Debounced analysis prevents excessive processing
- **Memory Conscious** - Cleans up tooltips and event listeners
- **Non-blocking** - Doesn't interfere with website functionality

## Troubleshooting

### Extension Not Working
1. Check if Developer mode is enabled
2. Reload the extension from chrome://extensions/
3. Refresh the webpage you're testing on

### Tooltips Not Appearing
1. Ensure the extension is enabled in popup
2. Check if you're typing in a supported text field
3. Verify the analysis delay setting isn't too high

### Permission Issues
The extension only requires:
- `activeTab` - To interact with current webpage
- `storage` - To save your preferences

### Performance Issues
If the extension feels slow:
1. Increase the analysis delay in settings
2. Disable confidence display for faster rendering
3. Check browser console for any errors

## Future Enhancements

- **Server Integration** - Connect to web app's ML training system
- **Custom Dictionaries** - User-defined emotion keywords
- **Keyboard Shortcuts** - Quick emoji insertion hotkeys
- **Analytics Dashboard** - Detailed usage insights
- **Team Sync** - Share learning data across devices
- **More Platforms** - Support for additional browsers

## Support

For issues, feature requests, or questions:
1. Check this README for common solutions
2. Test with the web app at the training interface
3. Report bugs with browser console logs
4. Suggest features for future versions

## License

This extension is part of the Emoji Tone Detector project. All rights reserved.