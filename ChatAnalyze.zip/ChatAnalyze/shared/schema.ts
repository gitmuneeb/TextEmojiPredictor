import { pgTable, text, serial, integer, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const toneAnalyses = pgTable("tone_analyses", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  detectedTone: text("detected_tone").notNull(),
  confidence: integer("confidence").notNull(),
  keywords: json("keywords").$type<string[]>().notNull(),
  emojis: json("emojis").$type<string[]>().notNull(),
});

// Training data table for machine learning
export const trainingData = pgTable("training_data", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  correctTone: text("correct_tone").notNull(),
  userFeedback: text("user_feedback"), // 'positive', 'negative', 'neutral'
  timestamp: text("timestamp").notNull(),
  originalPrediction: text("original_prediction"),
  confidence: integer("confidence"),
});

// User corrections table
export const userCorrections = pgTable("user_corrections", {
  id: serial("id").primaryKey(),
  originalText: text("original_text").notNull(),
  predictedTone: text("predicted_tone").notNull(),
  correctedTone: text("corrected_tone").notNull(),
  userId: text("user_id"), // For future user tracking
  timestamp: text("timestamp").notNull(),
});

export const insertToneAnalysisSchema = createInsertSchema(toneAnalyses).pick({
  text: true,
  detectedTone: true,
  confidence: true,
  keywords: true,
  emojis: true,
});

export type InsertToneAnalysis = z.infer<typeof insertToneAnalysisSchema>;
export type ToneAnalysis = typeof toneAnalyses.$inferSelect;

// Request/Response schemas
export const analyzeTextSchema = z.object({
  text: z.string().min(1).max(500, "Message must be 500 characters or less"),
});

export const toneAnalysisResponseSchema = z.object({
  tone: z.string(),
  confidence: z.number().min(0).max(100),
  keywords: z.array(z.string()),
  emojis: z.array(z.string()),
});

export type AnalyzeTextRequest = z.infer<typeof analyzeTextSchema>;
export type ToneAnalysisResponse = z.infer<typeof toneAnalysisResponseSchema>;

// Training schemas
export const trainDataSchema = z.object({
  text: z.string().min(1).max(500),
  correctTone: z.string(),
  userFeedback: z.enum(['positive', 'negative', 'neutral']).optional(),
});

export const userCorrectionSchema = z.object({
  originalText: z.string().min(1).max(500),
  predictedTone: z.string(),
  correctedTone: z.string(),
});

export const feedbackSchema = z.object({
  analysisId: z.number().optional(),
  text: z.string().min(1).max(500),
  predictedTone: z.string(),
  feedback: z.enum(['correct', 'incorrect']),
  suggestedTone: z.string().optional(),
});

export type TrainDataRequest = z.infer<typeof trainDataSchema>;
export type UserCorrectionRequest = z.infer<typeof userCorrectionSchema>;
export type FeedbackRequest = z.infer<typeof feedbackSchema>;

// Insert schemas
export const insertTrainingDataSchema = createInsertSchema(trainingData).omit({
  id: true,
  timestamp: true,
});

export const insertUserCorrectionSchema = createInsertSchema(userCorrections).omit({
  id: true,
  timestamp: true,
});

export type InsertTrainingData = z.infer<typeof insertTrainingDataSchema>;
export type InsertUserCorrection = z.infer<typeof insertUserCorrectionSchema>;
export type TrainingData = typeof trainingData.$inferSelect;
export type UserCorrection = typeof userCorrections.$inferSelect;
