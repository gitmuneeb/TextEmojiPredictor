import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  analyzeTextSchema, 
  trainDataSchema,
  userCorrectionSchema,
  feedbackSchema,
  type AnalyzeTextRequest, 
  type ToneAnalysisResponse,
  type TrainDataRequest,
  type UserCorrectionRequest,
  type FeedbackRequest
} from "@shared/schema";

// Emoji mapping based on keywords and sentiment
const EMOJI_MAP = {
  'positive': ['😀', '😃', '😄', '😁', '😆', '😊', '😍', '🥰', '😎', '🤩'],
  'negative': ['😞', '😔', '😟', '🙁', '☹️', '😣', '😖', '😫', '😩', '😤'],
  'neutral': ['😐', '😑', '😶', '🙄', '😏', '😒', '🤔', '🤨', '🧐', '😌'],
  'excited': ['🎉', '🎊', '🥳', '💃', '🕺', '🔥', '✨', '💫', '👏', '🙌'],
  'angry': ['😠', '😡', '🤬', '😤', '💢', '💥', '💣', '👺', '💀', '🩸'],
  'love': ['❤️', '💕', '💖', '💗', '💓', '💞', '💘', '💝', '💟', '💌'],
  'funny': ['😂', '🤣', '😹', '😆', '😜', '🤪', '🤡', '🃏', '🎭', '🎪'],
  'sad': ['😢', '😭', '😿', '💔', '🥺', '😓', '😥', '😰', '😨', '😱'],
  'surprise': ['😲', '😳', '😦', '😧', '😮', '😵', '🤯', '👽', '👀', '🧠'],
  'celebration': ['🎂', '🍰', '🍾', '🍷', '🥂', '🍻', '🎁', '🎈', '🎯', '🏆']
};

// Machine learning weights for dynamic keyword scoring
let LEARNED_WEIGHTS: Record<string, Record<string, number>> = {};

// Enhanced keywords with context and intensity
const KEYWORDS = {
  'positive': {
    strong: ['fantastic', 'amazing', 'wonderful', 'excellent', 'brilliant', 'outstanding', 'perfect', 'incredible'],
    medium: ['good', 'great', 'nice', 'pleasant', 'lovely', 'beautiful', 'awesome', 'cool'],
    light: ['okay', 'fine', 'alright', 'decent', 'not bad', 'satisfactory']
  },
  'negative': {
    strong: ['terrible', 'awful', 'horrible', 'disgusting', 'worst', 'hate', 'despise', 'catastrophic'],
    medium: ['bad', 'poor', 'disappointing', 'unfortunate', 'unpleasant', 'wrong', 'failed'],
    light: ['meh', 'not great', 'could be better', 'disappointing', 'lacking']
  },
  'excited': {
    strong: ['ecstatic', 'thrilled', 'pumped', 'hyped', 'stoked', 'overjoyed', 'euphoric'],
    medium: ['excited', 'eager', 'enthusiastic', 'looking forward', 'anticipating'],
    light: ['interested', 'curious', 'hopeful', 'optimistic']
  },
  'angry': {
    strong: ['furious', 'livid', 'enraged', 'outraged', 'infuriated', 'irate'],
    medium: ['angry', 'mad', 'annoyed', 'irritated', 'frustrated', 'upset'],
    light: ['bothered', 'irked', 'miffed', 'displeased']
  },
  'love': {
    strong: ['adore', 'worship', 'cherish', 'treasure', 'devoted', 'passionate'],
    medium: ['love', 'care about', 'fond of', 'affection', 'romantic', 'crush'],
    light: ['like', 'enjoy', 'appreciate', 'prefer']
  },
  'funny': {
    strong: ['hilarious', 'hysterical', 'ridiculous', 'absurd', 'laughing my head off'],
    medium: ['funny', 'amusing', 'entertaining', 'witty', 'clever', 'comical'],
    light: ['silly', 'cute', 'quirky', 'playful', 'chuckling']
  },
  'sad': {
    strong: ['devastated', 'heartbroken', 'depressed', 'miserable', 'grief', 'anguish'],
    medium: ['sad', 'down', 'blue', 'melancholy', 'sorrowful', 'unhappy'],
    light: ['disappointed', 'bummed', 'discouraged', 'wistful']
  },
  'surprise': {
    strong: ['shocked', 'stunned', 'flabbergasted', 'mind-blown', 'speechless'],
    medium: ['surprised', 'amazed', 'astonished', 'startled', 'unexpected'],
    light: ['interesting', 'curious', 'unusual', 'different']
  },
  'celebration': {
    strong: ['celebrating', 'victorious', 'triumphant', 'champion', 'accomplished'],
    medium: ['party', 'birthday', 'anniversary', 'graduation', 'success', 'achievement'],
    light: ['finished', 'completed', 'done', 'milestone']
  }
};

// Negation words that flip sentiment
const NEGATION_WORDS = ['not', 'no', 'never', 'nothing', 'nobody', 'nowhere', 'neither', 'nor', 'hardly', 'barely', 'rarely', 'seldom', 'without', 'lack', 'missing', 'absent', 'cannot', "can't", "won't", "shouldn't", "wouldn't", "couldn't", "don't", "doesn't", "didn't", "isn't", "aren't", "wasn't", "weren't"];

// Context modifiers
const INTENSIFIERS = ['very', 'really', 'extremely', 'incredibly', 'absolutely', 'totally', 'completely', 'utterly', 'quite', 'rather', 'pretty', 'fairly', 'somewhat', 'kind of', 'sort of', 'a bit', 'a little', 'so', 'too', 'super', 'mega', 'ultra'];

// Question words that might indicate uncertainty
const QUESTION_WORDS = ['what', 'how', 'why', 'when', 'where', 'who', 'which', 'could', 'would', 'should', 'might', 'maybe', 'perhaps', 'possibly'];

// Sentence patterns that indicate specific emotions
const SENTENCE_PATTERNS = {
  excited: [/can'?t wait/i, /so excited/i, /looking forward/i, /finally/i],
  happy: [/feel good/i, /feeling great/i, /in a good mood/i, /having fun/i],
  sad: [/feel sad/i, /feeling down/i, /having a hard time/i, /going through/i],
  angry: [/so annoying/i, /drives me crazy/i, /sick of/i, /fed up/i],
  love: [/in love/i, /love you/i, /care about/i, /mean everything/i],
  celebration: [/got the job/i, /passed the/i, /graduated/i, /won the/i, /just got/i]
};

// Machine learning helper functions
async function updateLearningWeights() {
  const corrections = await storage.getUserCorrections();
  const trainingData = await storage.getTrainingData();
  
  // Reset weights
  LEARNED_WEIGHTS = {};
  
  // Analyze user corrections to adjust keyword weights
  corrections.forEach(correction => {
    const words = correction.originalText.toLowerCase().split(/[\s.,!?;:]+/).filter(w => w.length > 0);
    const predictedTone = correction.predictedTone;
    const correctTone = correction.correctedTone;
    
    if (!LEARNED_WEIGHTS[correctTone]) {
      LEARNED_WEIGHTS[correctTone] = {};
    }
    
    // Increase weight for words that should indicate the correct tone
    words.forEach(word => {
      if (!LEARNED_WEIGHTS[correctTone][word]) {
        LEARNED_WEIGHTS[correctTone][word] = 0;
      }
      LEARNED_WEIGHTS[correctTone][word] += 0.5;
    });
  });
  
  // Analyze training data
  trainingData.forEach(data => {
    const words = data.text.toLowerCase().split(/[\s.,!?;:]+/).filter(w => w.length > 0);
    const correctTone = data.correctTone;
    
    if (!LEARNED_WEIGHTS[correctTone]) {
      LEARNED_WEIGHTS[correctTone] = {};
    }
    
    words.forEach(word => {
      if (!LEARNED_WEIGHTS[correctTone][word]) {
        LEARNED_WEIGHTS[correctTone][word] = 0;
      }
      LEARNED_WEIGHTS[correctTone][word] += 0.3;
    });
  });
}

function detectTone(text: string): { tone: string; keywords: string[] } {
  const originalText = text;
  const lowerText = text.toLowerCase();
  const words = lowerText.split(/[\s.,!?;:]+/).filter(word => word.length > 0);
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  
  const toneScores: Record<string, number> = {};
  const detectedKeywords: string[] = [];

  // Initialize scores
  Object.keys(KEYWORDS).forEach(tone => toneScores[tone] = 0);

  // Analyze sentence patterns first (higher weight)
  Object.entries(SENTENCE_PATTERNS).forEach(([tone, patterns]) => {
    patterns.forEach(pattern => {
      if (pattern.test(originalText)) {
        toneScores[tone] += 4;
        detectedKeywords.push('sentence pattern');
      }
    });
  });

  // Apply machine learning weights first
  words.forEach(word => {
    Object.entries(LEARNED_WEIGHTS).forEach(([tone, wordWeights]) => {
      if (wordWeights[word]) {
        toneScores[tone] += wordWeights[word];
        detectedKeywords.push(`learned:${word}`);
      }
    });
  });

  // Analyze words with context awareness
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const prevWord = i > 0 ? words[i - 1] : '';
    const nextWord = i < words.length - 1 ? words[i + 1] : '';
    
    // Check for negation context (within 2 words)
    const hasNegation = NEGATION_WORDS.some(neg => 
      (i > 0 && words[i - 1] === neg) || 
      (i > 1 && words[i - 2] === neg)
    );
    
    // Check for intensifiers
    const hasIntensifier = INTENSIFIERS.includes(prevWord);
    const intensifierMultiplier = hasIntensifier ? 1.5 : 1;

    // Analyze each tone category
    Object.entries(KEYWORDS).forEach(([tone, intensityLevels]) => {
      let baseScore = 0;
      let matchedKeyword = '';

      // Check strong keywords (weight: 3)
      if (intensityLevels.strong.some(keyword => word.includes(keyword) || keyword.includes(word))) {
        baseScore = 3;
        matchedKeyword = word;
      }
      // Check medium keywords (weight: 2)
      else if (intensityLevels.medium.some(keyword => word.includes(keyword) || keyword.includes(word))) {
        baseScore = 2;
        matchedKeyword = word;
      }
      // Check light keywords (weight: 1)
      else if (intensityLevels.light.some(keyword => word.includes(keyword) || keyword.includes(word))) {
        baseScore = 1;
        matchedKeyword = word;
      }

      if (baseScore > 0) {
        // Apply context modifications
        let finalScore = baseScore * intensifierMultiplier;
        
        // Handle negation - flip sentiment for positive/negative emotions
        if (hasNegation) {
          if (tone === 'positive') {
            toneScores['negative'] += finalScore;
            detectedKeywords.push(`NOT ${matchedKeyword}`);
          } else if (tone === 'negative') {
            toneScores['positive'] += finalScore * 0.7; // Weaker positive from double negative
            detectedKeywords.push(`NOT ${matchedKeyword}`);
          } else {
            finalScore *= 0.5; // Reduce other emotions when negated
            toneScores[tone] += finalScore;
            detectedKeywords.push(`NOT ${matchedKeyword}`);
          }
        } else {
          toneScores[tone] += finalScore;
          detectedKeywords.push(matchedKeyword);
        }
      }
    });
  }

  // Question analysis - reduces confidence but doesn't eliminate emotion
  const hasQuestions = QUESTION_WORDS.some(q => lowerText.includes(q)) || text.includes('?');
  if (hasQuestions) {
    Object.keys(toneScores).forEach(tone => {
      toneScores[tone] *= 0.8; // Reduce all scores for questions
    });
    detectedKeywords.push('question');
  }

  // Enhanced punctuation analysis
  if (text.includes('!!!') || text.includes('!!')) {
    toneScores['excited'] += 3;
    detectedKeywords.push('multiple exclamation');
  } else if (text.includes('!')) {
    toneScores['excited'] += 1;
    detectedKeywords.push('exclamation');
  }

  if (text.includes(':(') || text.includes(":'(") || text.includes('☹️')) {
    toneScores['sad'] += 3;
    detectedKeywords.push('sad emoticon');
  }

  if (text.includes(':)') || text.includes(':D') || text.includes('😊')) {
    toneScores['positive'] += 2;
    detectedKeywords.push('happy emoticon');
  }

  if (text.includes('...')) {
    toneScores['sad'] += 1;
    toneScores['neutral'] += 1;
    detectedKeywords.push('ellipsis');
  }

  // Caps analysis
  const capsWords = originalText.split(' ').filter(word => 
    word.length > 2 && word === word.toUpperCase() && /[A-Z]/.test(word)
  );
  if (capsWords.length > 0) {
    toneScores['excited'] += capsWords.length;
    toneScores['angry'] += capsWords.length * 0.5;
    detectedKeywords.push('CAPS');
  }

  // Context-aware tone selection
  let dominantTone = 'neutral';
  let maxScore = 1; // Minimum threshold

  Object.entries(toneScores).forEach(([tone, score]) => {
    if (score > maxScore) {
      maxScore = score;
      dominantTone = tone;
    }
  });

  // Special logic for mixed emotions
  const sortedTones = Object.entries(toneScores)
    .sort(([,a], [,b]) => b - a)
    .filter(([,score]) => score > 0);

  // If scores are very close, choose more specific emotion
  if (sortedTones.length >= 2) {
    const [first, second] = sortedTones;
    const scoreDiff = first[1] - second[1];
    
    if (scoreDiff < 1) {
      // Prefer more specific emotions over general ones
      const specificityOrder = ['love', 'excited', 'angry', 'funny', 'sad', 'surprise', 'celebration', 'positive', 'negative', 'neutral'];
      for (const specificTone of specificityOrder) {
        if ([first[0], second[0]].includes(specificTone)) {
          dominantTone = specificTone;
          break;
        }
      }
    }
  }

  return {
    tone: dominantTone,
    keywords: Array.from(new Set(detectedKeywords)).slice(0, 5) // Limit keywords for clarity
  };
}

function calculateConfidence(keywords: string[], text: string, tone: string): number {
  const words = text.split(/[\s.,!?;:]+/).filter(word => word.length > 0);
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  
  let confidence = 30; // Base confidence
  
  // Keyword density (max 30 points)
  const keywordDensity = keywords.length / Math.max(words.length, 1);
  confidence += Math.min(30, keywordDensity * 100);
  
  // Sentence pattern bonus (10 points)
  if (keywords.includes('sentence pattern')) {
    confidence += 10;
  }
  
  // Punctuation clarity (10 points)
  if (keywords.some(k => k.includes('emoticon') || k.includes('exclamation'))) {
    confidence += 10;
  }
  
  // Length bonus - longer texts are more reliable (max 10 points)
  if (words.length >= 5) {
    confidence += Math.min(10, words.length / 2);
  }
  
  // Negation penalty - reduces confidence
  if (keywords.some(k => k.startsWith('NOT'))) {
    confidence -= 10;
  }
  
  // Question penalty - questions are less certain
  if (keywords.includes('question')) {
    confidence -= 15;
  }
  
  // Very short text penalty
  if (words.length < 3) {
    confidence -= 20;
  }
  
  // Neutral tone gets lower confidence
  if (tone === 'neutral') {
    confidence = Math.min(confidence, 60);
  }
  
  return Math.min(95, Math.max(15, Math.round(confidence)));
}

function getRandomEmojis(tone: string, count: number = 5): string[] {
  const emojis = EMOJI_MAP[tone as keyof typeof EMOJI_MAP] || EMOJI_MAP['neutral'];
  const shuffled = [...emojis].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.min(count, emojis.length));
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Analyze text and return tone with emoji suggestions
  app.post("/api/analyze", async (req, res) => {
    try {
      const parseResult = analyzeTextSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid input", 
          errors: parseResult.error.issues 
        });
      }

      const { text } = parseResult.data;
      
      // Detect tone and keywords
      const { tone, keywords } = detectTone(text);
      
      // Calculate confidence
      const confidence = calculateConfidence(keywords, text, tone);
      
      // Get emoji suggestions
      const emojis = getRandomEmojis(tone);

      const response: ToneAnalysisResponse = {
        tone,
        confidence,
        keywords,
        emojis
      };

      // Store the analysis
      await storage.createToneAnalysis({
        text,
        detectedTone: tone,
        confidence,
        keywords,
        emojis
      });

      res.json(response);
    } catch (error) {
      console.error("Error analyzing text:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Training endpoints
  app.post("/api/train", async (req, res) => {
    try {
      const parseResult = trainDataSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({
          message: "Invalid training data",
          errors: parseResult.error.issues
        });
      }

      const { text, correctTone, userFeedback } = parseResult.data;
      
      // Get current prediction to compare
      const currentPrediction = detectTone(text);
      
      await storage.addTrainingData({
        text,
        correctTone,
        userFeedback,
        originalPrediction: currentPrediction.tone,
        confidence: calculateConfidence(currentPrediction.keywords, text, currentPrediction.tone)
      });

      // Update learning weights
      await updateLearningWeights();

      res.json({ 
        message: "Training data added successfully",
        originalPrediction: currentPrediction.tone,
        correctTone
      });
    } catch (error) {
      console.error("Error adding training data:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/correct", async (req, res) => {
    try {
      const parseResult = userCorrectionSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({
          message: "Invalid correction data",
          errors: parseResult.error.issues
        });
      }

      const { originalText, predictedTone, correctedTone } = parseResult.data;
      
      await storage.addUserCorrection({
        originalText,
        predictedTone,
        correctedTone,
        userId: null // For future user tracking
      });

      // Update learning weights
      await updateLearningWeights();

      res.json({ 
        message: "Correction recorded successfully",
        improvedAnalysis: detectTone(originalText)
      });
    } catch (error) {
      console.error("Error recording correction:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/feedback", async (req, res) => {
    try {
      const parseResult = feedbackSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({
          message: "Invalid feedback",
          errors: parseResult.error.issues
        });
      }

      const { text, predictedTone, feedback, suggestedTone } = parseResult.data;
      
      if (feedback === 'incorrect' && suggestedTone) {
        // Record as correction
        await storage.addUserCorrection({
          originalText: text,
          predictedTone,
          correctedTone: suggestedTone,
          userId: null
        });
        
        // Update weights
        await updateLearningWeights();
      } else if (feedback === 'correct') {
        // Record as positive training data
        await storage.addTrainingData({
          text,
          correctTone: predictedTone,
          userFeedback: 'positive',
          originalPrediction: predictedTone,
          confidence: null
        });
      }

      res.json({ message: "Feedback recorded successfully" });
    } catch (error) {
      console.error("Error recording feedback:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get training statistics
  app.get("/api/training-stats", async (req, res) => {
    try {
      const trainingData = await storage.getTrainingData();
      const corrections = await storage.getUserCorrections();
      
      const stats = {
        totalTrainingEntries: trainingData.length,
        totalCorrections: corrections.length,
        toneDistribution: {} as Record<string, number>,
        correctionPatterns: {} as Record<string, { from: string; to: string; count: number }[]>,
        learningProgress: Object.keys(LEARNED_WEIGHTS).length
      };

      // Calculate tone distribution
      trainingData.forEach(data => {
        stats.toneDistribution[data.correctTone] = (stats.toneDistribution[data.correctTone] || 0) + 1;
      });

      // Calculate correction patterns
      corrections.forEach(correction => {
        const pattern = `${correction.predictedTone}→${correction.correctedTone}`;
        if (!stats.correctionPatterns[pattern]) {
          stats.correctionPatterns[pattern] = [];
        }
        stats.correctionPatterns[pattern].push({
          from: correction.predictedTone,
          to: correction.correctedTone,
          count: 1
        });
      });

      res.json(stats);
    } catch (error) {
      console.error("Error getting training stats:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all tone categories for reference
  app.get("/api/tone-categories", (req, res) => {
    const categories = Object.keys(EMOJI_MAP).map(tone => ({
      name: tone,
      emoji: EMOJI_MAP[tone as keyof typeof EMOJI_MAP][0]
    }));
    
    res.json(categories);
  });

  const httpServer = createServer(app);
  return httpServer;
}
