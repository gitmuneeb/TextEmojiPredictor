import { 
  toneAnalyses, 
  trainingData, 
  userCorrections,
  type ToneAnalysis, 
  type InsertToneAnalysis,
  type TrainingData,
  type InsertTrainingData,
  type UserCorrection,
  type InsertUserCorrection
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  createToneAnalysis(analysis: InsertToneAnalysis): Promise<ToneAnalysis>;
  getToneAnalyses(): Promise<ToneAnalysis[]>;
  
  // Training data methods
  addTrainingData(data: InsertTrainingData): Promise<TrainingData>;
  getTrainingData(): Promise<TrainingData[]>;
  getTrainingDataByTone(tone: string): Promise<TrainingData[]>;
  
  // User corrections methods
  addUserCorrection(correction: InsertUserCorrection): Promise<UserCorrection>;
  getUserCorrections(): Promise<UserCorrection[]>;
  getUserCorrectionsByText(text: string): Promise<UserCorrection[]>;
}

export class DatabaseStorage implements IStorage {
  async createToneAnalysis(insertAnalysis: InsertToneAnalysis): Promise<ToneAnalysis> {
    const [analysis] = await db
      .insert(toneAnalyses)
      .values({
        ...insertAnalysis,
        keywords: Array.isArray(insertAnalysis.keywords) ? insertAnalysis.keywords : Array.from(insertAnalysis.keywords),
        emojis: Array.isArray(insertAnalysis.emojis) ? insertAnalysis.emojis : Array.from(insertAnalysis.emojis)
      })
      .returning();
    return analysis;
  }

  async getToneAnalyses(): Promise<ToneAnalysis[]> {
    return await db.select().from(toneAnalyses);
  }

  // Training data methods
  async addTrainingData(data: InsertTrainingData): Promise<TrainingData> {
    const timestamp = new Date().toISOString();
    const [trainingEntry] = await db
      .insert(trainingData)
      .values({
        ...data,
        timestamp,
        userFeedback: data.userFeedback || null,
        originalPrediction: data.originalPrediction || null,
        confidence: data.confidence || null
      })
      .returning();
    return trainingEntry;
  }

  async getTrainingData(): Promise<TrainingData[]> {
    return await db.select().from(trainingData);
  }

  async getTrainingDataByTone(tone: string): Promise<TrainingData[]> {
    return await db
      .select()
      .from(trainingData)
      .where(eq(trainingData.correctTone, tone));
  }

  // User corrections methods
  async addUserCorrection(correction: InsertUserCorrection): Promise<UserCorrection> {
    const timestamp = new Date().toISOString();
    const [correctionEntry] = await db
      .insert(userCorrections)
      .values({
        ...correction,
        timestamp,
        userId: correction.userId || null
      })
      .returning();
    return correctionEntry;
  }

  async getUserCorrections(): Promise<UserCorrection[]> {
    return await db.select().from(userCorrections);
  }

  async getUserCorrectionsByText(text: string): Promise<UserCorrection[]> {
    return await db
      .select()
      .from(userCorrections)
      .where(eq(userCorrections.originalText, text));
  }
}

export const storage = new DatabaseStorage();
