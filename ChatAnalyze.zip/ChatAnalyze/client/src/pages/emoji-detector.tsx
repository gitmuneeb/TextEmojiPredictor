import { useState, useEffect, useCallback } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Smile, 
  Sparkles, 
  TrendingUp, 
  Palette, 
  Lightbulb, 
  Edit,
  Eraser,
  CheckCircle,
  Info,
  MessageCircle
} from "lucide-react";
import type { AnalyzeTextRequest, ToneAnalysisResponse } from "@shared/schema";

interface ToneCategory {
  name: string;
  emoji: string;
}

const EXAMPLE_MESSAGES = [
  {
    title: "Excited Example",
    text: "I'm so excited about the concert tonight!! Can't wait! 🎵"
  },
  {
    title: "Love Example", 
    text: "I love spending time with my family ❤️"
  },
  {
    title: "Funny Example",
    text: "That joke was absolutely hilarious! I can't stop laughing 😂"
  },
  {
    title: "Sad Example",
    text: "I'm feeling really sad today :("
  }
];

export default function EmojiDetector() {
  const [message, setMessage] = useState("");
  const [analysis, setAnalysis] = useState<ToneAnalysisResponse | null>(null);
  const [currentEmoji, setCurrentEmoji] = useState<string>("😊");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  const { data: toneCategories } = useQuery({
    queryKey: ["/api/tone-categories"],
  });

  const analyzeMutation = useMutation({
    mutationFn: async (data: AnalyzeTextRequest) => {
      const response = await apiRequest("POST", "/api/analyze", data);
      return response.json() as Promise<ToneAnalysisResponse>;
    },
    onSuccess: (data) => {
      setAnalysis(data);
      setCurrentEmoji(data.emojis[0] || "😊");
      setIsAnalyzing(false);
    },
    onError: (error) => {
      setIsAnalyzing(false);
      setCurrentEmoji("😊");
    },
  });

  // Debounced analysis function
  const debouncedAnalyze = useCallback(
    debounce((text: string) => {
      if (text.trim().length > 2) {
        setIsAnalyzing(true);
        analyzeMutation.mutate({ text: text.trim() });
      } else {
        setCurrentEmoji("😊");
        setAnalysis(null);
        setIsAnalyzing(false);
      }
    }, 800),
    [analyzeMutation]
  );

  const handleAnalyze = () => {
    if (!message.trim()) {
      toast({
        title: "Input Required",
        description: "Please enter a message to analyze!",
        variant: "destructive",
      });
      return;
    }

    analyzeMutation.mutate({ text: message.trim() });
  };

  // Handle text change with real-time analysis
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value;
    setMessage(newText);
    debouncedAnalyze(newText);
  };

  const handleClear = () => {
    setMessage("");
    setAnalysis(null);
    setCurrentEmoji("😊");
    setIsAnalyzing(false);
  };

  const handleExampleClick = (exampleText: string) => {
    setMessage(exampleText);
    debouncedAnalyze(exampleText);
  };

  const copyEmoji = async (emoji: string) => {
    try {
      await navigator.clipboard.writeText(emoji);
      toast({
        title: "Copied!",
        description: "Emoji copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Unable to copy emoji to clipboard",
        variant: "destructive",
      });
    }
  };

  const getToneColor = (tone: string) => {
    const colors: Record<string, string> = {
      'positive': 'bg-green-100 text-green-800 border-green-200',
      'excited': 'bg-indigo-100 text-indigo-800 border-indigo-200',
      'love': 'bg-pink-100 text-pink-800 border-pink-200',
      'funny': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'sad': 'bg-blue-100 text-blue-800 border-blue-200',
      'angry': 'bg-red-100 text-red-800 border-red-200',
      'surprise': 'bg-purple-100 text-purple-800 border-purple-200',
      'celebration': 'bg-indigo-100 text-indigo-800 border-indigo-200',
      'neutral': 'bg-gray-100 text-gray-800 border-gray-200',
      'negative': 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[tone] || colors['neutral'];
  };

  // Simple debounce function
  function debounce<T extends (...args: any[]) => void>(
    func: T,
    wait: number
  ): (...args: Parameters<T>) => void {
    let timeout: NodeJS.Timeout;
    return (...args: Parameters<T>) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => func(...args), wait);
    };
  }

  return (
    <div className="bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-3">
              <MessageCircle className="h-8 w-8 text-indigo-600" />
              Live Emoji Chat
            </h1>
            <p className="text-gray-600 text-lg">
              Type your message and watch emojis appear in real-time
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Chat-like Input Section */}
        <Card className="shadow-lg border-gray-200 mb-8">
          <CardContent className="p-6 md:p-8">
            <div className="mb-6">
              <label htmlFor="messageInput" className="block text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-indigo-600" />
                Type Your Message
              </label>
              
              {/* Chat-like container with emoji display */}
              <div className="relative bg-gray-50 rounded-lg border-2 border-gray-200 focus-within:border-indigo-600 transition-colors">
                <Textarea
                  id="messageInput"
                  placeholder="Start typing... emoji will appear as you type!"
                  value={message}
                  onChange={handleTextChange}
                  className="min-h-[120px] md:min-h-[160px] text-base border-0 bg-transparent resize-none focus:ring-0 pr-20"
                  maxLength={500}
                />
                
                {/* Live emoji display */}
                <div className="absolute top-4 right-4 flex flex-col items-center gap-2">
                  <div className="text-4xl transition-all duration-300 hover:scale-110">
                    {isAnalyzing ? "🤔" : currentEmoji}
                  </div>
                  {analysis && (
                    <Badge className={`text-xs ${getToneColor(analysis.tone)}`}>
                      {analysis.tone}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-500 flex items-center gap-1">
                  <Info className="h-4 w-4" />
                  {isAnalyzing ? "Analyzing..." : "Emoji updates as you type"}
                </span>
                <span className={`text-sm ${message.length > 450 ? 'text-red-500' : 'text-gray-400'}`}>
                  {message.length}/500
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button 
                onClick={handleClear}
                variant="outline"
                className="sm:w-auto bg-gray-500 hover:bg-gray-600 text-white border-gray-500 hover:border-gray-600 font-medium py-3 px-6"
              >
                <Eraser className="h-5 w-5 mr-2" />
                Clear Message
              </Button>
              <Button 
                onClick={() => copyEmoji(currentEmoji)}
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 text-base shadow-lg"
              >
                <span className="mr-2">{currentEmoji}</span>
                Copy Emoji
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Live Analysis Results */}
        {analysis && message.trim().length > 2 && (
          <div className="space-y-6">
            {/* Primary Emoji Display */}
            <Card className="shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-pink-500" />
                  Live Analysis Result
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border-2 border-dashed border-gray-300">
                  <div className="text-6xl md:text-7xl mb-4 cursor-pointer hover:scale-110 transition-transform duration-200" onClick={() => copyEmoji(currentEmoji)}>
                    {currentEmoji}
                  </div>
                  <p className="text-gray-600 text-sm mb-2">Primary emoji suggestion</p>
                  <p className="text-gray-500 text-xs">Click to copy to clipboard</p>
                </div>
              </CardContent>
            </Card>

            {/* Additional Emoji Options */}
            <Card className="shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                  <Palette className="h-5 w-5 text-yellow-500" />
                  More Options
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                  <div className="text-4xl md:text-5xl mb-4 space-x-3">
                    {analysis.emojis.slice(1).map((emoji, index) => (
                      <span
                        key={index}
                        className="cursor-pointer hover:scale-110 transition-transform duration-200 inline-block"
                        onClick={() => copyEmoji(emoji)}
                      >
                        {emoji}
                      </span>
                    ))}
                  </div>
                  <p className="text-gray-600 text-sm">Alternative suggestions</p>
                </div>
              </CardContent>
            </Card>

            {/* Tone Analysis */}
            <Card className="shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  Tone Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Primary Tone */}
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-indigo-50 to-indigo-25 rounded-xl border border-indigo-200">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-indigo-600 rounded-full"></div>
                    <span className="font-medium text-gray-900">Primary Tone:</span>
                    <Badge className={getToneColor(analysis.tone)}>
                      {analysis.tone.charAt(0).toUpperCase() + analysis.tone.slice(1)}
                    </Badge>
                  </div>
                  <div className="text-2xl">{analysis.emojis[0]}</div>
                </div>

                {/* Confidence Score */}
                <div className="p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">Confidence Level</span>
                    <span className="text-sm font-semibold text-gray-900">{analysis.confidence}%</span>
                  </div>
                  <Progress value={analysis.confidence} className="h-3" />
                </div>

                {/* Keywords Detected */}
                <div className="p-4 bg-gray-50 rounded-xl">
                  <h3 className="text-sm font-medium text-gray-700 mb-3">Keywords Detected:</h3>
                  <div className="flex flex-wrap gap-2">
                    {analysis.keywords.length > 0 ? (
                      analysis.keywords.map((keyword, index) => (
                        <Badge key={index} variant="secondary" className="bg-indigo-100 text-indigo-800">
                          {keyword}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-gray-500 text-sm">No specific keywords detected</span>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tone Categories Reference */}
            <Card className="shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                  <Palette className="h-5 w-5 text-yellow-500" />
                  Supported Tone Categories
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {(toneCategories as ToneCategory[])?.map((category: ToneCategory) => (
                    <div key={category.name} className="text-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div className="text-2xl mb-2">{category.emoji}</div>
                      <div className="text-sm font-medium text-gray-900 capitalize">{category.name}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Examples Section */}
        <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200 mt-8">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-yellow-500" />
              Try These Live Examples
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {EXAMPLE_MESSAGES.map((example, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="text-left p-4 h-auto bg-white border-gray-200 hover:border-indigo-600 hover:shadow-md transition-all duration-200"
                  onClick={() => handleExampleClick(example.text)}
                >
                  <div>
                    <div className="text-sm font-medium text-gray-900 mb-1">{example.title}</div>
                    <div className="text-sm text-gray-600">"{example.text}"</div>
                  </div>
                </Button>
              ))}
            </div>
            <div className="mt-4 p-4 bg-white rounded-lg border border-gray-200">
              <p className="text-sm text-gray-600 text-center">
                💡 <strong>Tip:</strong> Start typing any message and watch the emoji change in real-time!
              </p>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center text-gray-600">
            <p className="mb-2">🚀 Real-time emoji suggestions powered by live sentiment analysis</p>
            <p className="text-sm">Features automatic tone detection, keyword analysis, and instant emoji matching</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
