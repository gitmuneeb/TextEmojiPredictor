import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Brain, 
  Target, 
  BookOpen, 
  TrendingUp, 
  BarChart3,
  CheckCircle,
  XCircle,
  ThumbsUp,
  ThumbsDown,
  Sparkles
} from "lucide-react";
import type { TrainDataRequest, UserCorrectionRequest, FeedbackRequest } from "@shared/schema";

interface TrainingStats {
  totalTrainingEntries: number;
  totalCorrections: number;
  toneDistribution: Record<string, number>;
  correctionPatterns: Record<string, { from: string; to: string; count: number }[]>;
  learningProgress: number;
}

const TONE_OPTIONS = [
  'positive', 'negative', 'neutral', 'excited', 'angry', 'love', 'funny', 'sad', 'surprise', 'celebration'
];

export default function Training() {
  const [trainText, setTrainText] = useState("");
  const [correctTone, setCorrectTone] = useState("");
  const [correctionText, setCorrectionText] = useState("");
  const [predictedTone, setPredictedTone] = useState("");
  const [correctedTone, setCorrectedTone] = useState("");
  const [testText, setTestText] = useState("");
  const [testResult, setTestResult] = useState<any>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch training statistics
  const { data: stats, refetch: refetchStats } = useQuery<TrainingStats>({
    queryKey: ["/api/training-stats"],
  });

  // Test current model
  const testMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await apiRequest("POST", "/api/analyze", { text });
      return response.json();
    },
    onSuccess: (data) => {
      setTestResult(data);
    },
  });

  // Add training data
  const trainMutation = useMutation({
    mutationFn: async (data: TrainDataRequest) => {
      const response = await apiRequest("POST", "/api/train", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Training Data Added",
        description: "The model has been updated with your training example.",
      });
      setTrainText("");
      setCorrectTone("");
      refetchStats();
    },
  });

  // Add correction
  const correctMutation = useMutation({
    mutationFn: async (data: UserCorrectionRequest) => {
      const response = await apiRequest("POST", "/api/correct", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Correction Recorded",
        description: "The model will learn from this correction.",
      });
      setCorrectionText("");
      setPredictedTone("");
      setCorrectedTone("");
      refetchStats();
    },
  });

  // Provide feedback
  const feedbackMutation = useMutation({
    mutationFn: async (data: FeedbackRequest) => {
      const response = await apiRequest("POST", "/api/feedback", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Feedback Recorded",
        description: "Thank you for helping improve the model!",
      });
    },
  });

  const handleTrain = () => {
    if (!trainText.trim() || !correctTone) {
      toast({
        title: "Missing Information",
        description: "Please provide both text and the correct tone.",
        variant: "destructive",
      });
      return;
    }

    trainMutation.mutate({
      text: trainText.trim(),
      correctTone,
      userFeedback: 'positive'
    });
  };

  const handleCorrect = () => {
    if (!correctionText.trim() || !predictedTone || !correctedTone) {
      toast({
        title: "Missing Information",
        description: "Please fill in all correction fields.",
        variant: "destructive",
      });
      return;
    }

    correctMutation.mutate({
      originalText: correctionText.trim(),
      predictedTone,
      correctedTone
    });
  };

  const handleTest = () => {
    if (!testText.trim()) {
      toast({
        title: "No Text to Test",
        description: "Please enter some text to analyze.",
        variant: "destructive",
      });
      return;
    }

    testMutation.mutate(testText.trim());
  };

  const handleFeedback = (correct: boolean, suggestedTone?: string) => {
    if (!testResult) return;

    feedbackMutation.mutate({
      text: testText,
      predictedTone: testResult.tone,
      feedback: correct ? 'correct' : 'incorrect',
      suggestedTone
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-3">
              <Brain className="h-8 w-8 text-indigo-600" />
              AI Training Center
            </h1>
            <p className="text-gray-600 text-lg">
              Help improve the emoji tone detection by providing training data and corrections
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Training Section */}
          <div className="space-y-6">
            {/* Add Training Data */}
            <Card className="shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                  <Target className="h-5 w-5 text-green-500" />
                  Add Training Example
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Example Text
                  </label>
                  <Textarea
                    placeholder="Enter text that should represent a specific emotion..."
                    value={trainText}
                    onChange={(e) => setTrainText(e.target.value)}
                    className="min-h-[100px]"
                    maxLength={500}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Correct Tone
                  </label>
                  <Select value={correctTone} onValueChange={setCorrectTone}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select the correct emotional tone" />
                    </SelectTrigger>
                    <SelectContent>
                      {TONE_OPTIONS.map(tone => (
                        <SelectItem key={tone} value={tone}>
                          {tone.charAt(0).toUpperCase() + tone.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={handleTrain}
                  disabled={trainMutation.isPending}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <BookOpen className="h-4 w-4 mr-2" />
                  {trainMutation.isPending ? "Adding..." : "Add Training Data"}
                </Button>
              </CardContent>
            </Card>

            {/* Correction Interface */}
            <Card className="shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                  <XCircle className="h-5 w-5 text-red-500" />
                  Report Incorrect Prediction
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Original Text
                  </label>
                  <Textarea
                    placeholder="Enter the text that was incorrectly analyzed..."
                    value={correctionText}
                    onChange={(e) => setCorrectionText(e.target.value)}
                    className="min-h-[80px]"
                    maxLength={500}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      AI Predicted
                    </label>
                    <Select value={predictedTone} onValueChange={setPredictedTone}>
                      <SelectTrigger>
                        <SelectValue placeholder="What did AI predict?" />
                      </SelectTrigger>
                      <SelectContent>
                        {TONE_OPTIONS.map(tone => (
                          <SelectItem key={tone} value={tone}>
                            {tone.charAt(0).toUpperCase() + tone.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Should Be
                    </label>
                    <Select value={correctedTone} onValueChange={setCorrectedTone}>
                      <SelectTrigger>
                        <SelectValue placeholder="What's correct?" />
                      </SelectTrigger>
                      <SelectContent>
                        {TONE_OPTIONS.map(tone => (
                          <SelectItem key={tone} value={tone}>
                            {tone.charAt(0).toUpperCase() + tone.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button 
                  onClick={handleCorrect}
                  disabled={correctMutation.isPending}
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  <Target className="h-4 w-4 mr-2" />
                  {correctMutation.isPending ? "Recording..." : "Submit Correction"}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Testing & Stats Section */}
          <div className="space-y-6">
            {/* Test Interface */}
            <Card className="shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-blue-500" />
                  Test Current Model
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Test Text
                  </label>
                  <Textarea
                    placeholder="Enter text to test the current model..."
                    value={testText}
                    onChange={(e) => setTestText(e.target.value)}
                    className="min-h-[100px]"
                    maxLength={500}
                  />
                </div>

                <Button 
                  onClick={handleTest}
                  disabled={testMutation.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <Brain className="h-4 w-4 mr-2" />
                  {testMutation.isPending ? "Analyzing..." : "Test Analysis"}
                </Button>

                {/* Test Results */}
                {testResult && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">Predicted Tone:</span>
                        <Badge className="bg-indigo-100 text-indigo-800">
                          {testResult.tone}
                        </Badge>
                      </div>
                      <div className="text-2xl">{testResult.emojis[0]}</div>
                    </div>
                    
                    <div className="text-sm text-gray-600 mb-3">
                      Confidence: {testResult.confidence}%
                    </div>

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleFeedback(true)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <ThumbsUp className="h-4 w-4 mr-1" />
                        Correct
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const suggested = prompt("What should the correct tone be?");
                          if (suggested) handleFeedback(false, suggested);
                        }}
                        className="border-red-500 text-red-600 hover:bg-red-50"
                      >
                        <ThumbsDown className="h-4 w-4 mr-1" />
                        Incorrect
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Training Statistics */}
            <Card className="shadow-lg border-gray-200">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-purple-500" />
                  Training Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                {stats ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">
                          {stats.totalTrainingEntries}
                        </div>
                        <div className="text-sm text-gray-600">Training Examples</div>
                      </div>
                      <div className="text-center p-3 bg-red-50 rounded-lg">
                        <div className="text-2xl font-bold text-red-600">
                          {stats.totalCorrections}
                        </div>
                        <div className="text-sm text-gray-600">Corrections Made</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-gray-700 mb-2">Tone Distribution</h4>
                      <div className="space-y-2">
                        {Object.entries(stats.toneDistribution).map(([tone, count]) => (
                          <div key={tone} className="flex justify-between text-sm">
                            <span className="capitalize">{tone}</span>
                            <span className="font-medium">{count}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-lg font-semibold text-blue-600">
                        Learning Progress: {stats.learningProgress} patterns learned
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-gray-500">
                    Loading training statistics...
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}