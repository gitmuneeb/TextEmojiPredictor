import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import EmojiDetector from "@/pages/emoji-detector";
import Training from "@/pages/training";
import { MessageCircle, Brain } from "lucide-react";

function Navigation() {
  const [location] = useLocation();
  
  return (
    <nav className="bg-white border-b border-gray-200 px-4 py-3">
      <div className="max-w-6xl mx-auto flex justify-center gap-4">
        <Link href="/">
          <Button 
            variant={location === "/" ? "default" : "outline"}
            className="flex items-center gap-2"
          >
            <MessageCircle className="h-4 w-4" />
            Live Chat
          </Button>
        </Link>
        <Link href="/training">
          <Button 
            variant={location === "/training" ? "default" : "outline"}
            className="flex items-center gap-2"
          >
            <Brain className="h-4 w-4" />
            AI Training
          </Button>
        </Link>
      </div>
    </nav>
  );
}

function Router() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Switch>
        <Route path="/" component={EmojiDetector} />
        <Route path="/training" component={Training} />
        <Route component={EmojiDetector} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
