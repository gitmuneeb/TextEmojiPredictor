// Simple content script for emoji detection
console.log('Emoji Tone Detector loaded!');

// Add a simple indicator that the extension is working
const indicator = document.createElement('div');
indicator.style.cssText = `
    position: fixed;
    top: 10px;
    right: 10px;
    background: #4CAF50;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 12px;
    z-index: 10000;
    font-family: Arial, sans-serif;
`;
indicator.textContent = '🧠 Emoji Detector Active';
document.body.appendChild(indicator);

// Remove indicator after 3 seconds
setTimeout(() => {
    if (indicator.parentNode) {
        indicator.parentNode.removeChild(indicator);
    }
}, 3000);

// Basic text input monitoring
document.addEventListener('input', (e) => {
    if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') {
        const text = e.target.value.toLowerCase();
        
        // Simple emotion detection
        if (text.length > 5) {
            let emoji = '';
            
            if (text.includes('happy') || text.includes('good') || text.includes('great')) {
                emoji = '😊';
            } else if (text.includes('excited') || text.includes('amazing')) {
                emoji = '🎉';
            } else if (text.includes('love')) {
                emoji = '❤️';
            } else if (text.includes('sad') || text.includes('bad')) {
                emoji = '😢';
            }
            
            if (emoji) {
                // Show a brief notification
                const tooltip = document.createElement('div');
                tooltip.style.cssText = `
                    position: absolute;
                    background: white;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    padding: 5px 10px;
                    font-size: 18px;
                    z-index: 10000;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                `;
                tooltip.textContent = emoji;
                
                const rect = e.target.getBoundingClientRect();
                tooltip.style.left = (rect.left + window.scrollX) + 'px';
                tooltip.style.top = (rect.bottom + window.scrollY + 5) + 'px';
                
                document.body.appendChild(tooltip);
                
                // Remove after 2 seconds
                setTimeout(() => {
                    if (tooltip.parentNode) {
                        tooltip.parentNode.removeChild(tooltip);
                    }
                }, 2000);
            }
        }
    }
});